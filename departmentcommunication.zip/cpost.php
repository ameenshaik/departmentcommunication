<?php
error_reporting(0);
    session_start();
    //copnnec to the database
    $db = mysqli_connect("localhost","root","","unify");
    //get all the submitted data from the form
    $image = addslashes(file_get_contents($_FILES["image"]["tmp_name"])); //$_FILES['image']['name'];
    $text = $_POST['text'];
    //$type = $_POST['type'];
    //echo $text." ".$type;
    $user = $_SESSION['uid'];
    $sql = "INSERT INTO post (image,description,id) VALUES ('$image','$text','$user')";
    mysqli_query($db,$sql);//stores the data
    include 'rpost.php';
    error_reporting(0);
    ini_set('display_errors', 0);
?>
<html>
<head>
    <link rel="stylesheet" href="mainpage.css">
    <div class="header">
    </div> 
</head>
<body>
    <h1 class="h1" style="margin-top:-2300px">
    <img src=logo.png>
    <a href="homepage.html"><input type="button" value="LOGOUT" name="LOGOUT"></a>
    <a href="events1.html"><input type="button" value="EVENTS" name="Events"></a>
    <a href="calendar.html"><input type="button" value="CALENDAR" name="Calendar"></a>
    <a href="messages1.html"><input type="button" value="MESSAGES" name="Messages"></a>
    <a href="profile.php"><input type="button" value="PROFILE" name="Profile"></a>
    <a href="post.php"><input type="button" value=" CREATE" name="Post"></a>

    
</h1>
</h1>
<h2 class="h2"></h2>
</body>
</html>