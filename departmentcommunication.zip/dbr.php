<?php
session_start();
?>
<html>
<head>
  <title>register</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<h1>Registered Succesfully</h1>
	<form method="post" action="1.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ameen";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$a=$_POST["hallticket"];
$b=$_POST["n"];
$c=$_POST["p"];
$m = "insert into user(hallticket,userid,password) values('$a','$b','$c')";
$r1 = mysqli_query($conn,$m);

?>
	
		<br>
<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Login</button>
  	</div>
	</form>
</body>
</html>