
<html>
<head>
  <link rel="stylesheet" href=".css">
<link rel="icon" href="lo.png">
</head>
<body>
  
   <!-- <img src="log.jpg" width="15%" style="position: absolute;margin-left: 550px;margin-top: 100px;">-->
  <div class="bg-modal">
  <div class="modal-content">
  <form method="post" action="mainpage.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$a=$_POST["id"];
session_start();
$_SESSION["uid"] = $a;
$b=$_POST["p"];
$m="select password from register where id='$a'";
$r1=mysqli_query($conn,$m);
while($row = mysqli_fetch_assoc($r1)) {
      // $c = $row["userid"];
       $d=$row["password"];
   }
   if($b==$d)
   {

  echo "<h3 style='background-color: ;
color: #262626;margin-left:530px;font-family:monospace'>You have Logged in succesfully</h3>";
  echo "<button type='submit' class='btn' name='reg_user' style='background-color:#80ff80;color:#ffffff;border:none;width:200px;height:50px;border-radius:5px;margin-top:320px;margin-left:41%'>continue</button>";
  echo"<img src='log.jpg' width=15% style='position:absolute;margin-top:100px;margin-left:-200px'>";
   }
   else
   {
   	echo "<h3 style='background-color: Tomato;width:100%;height:100%
color: #ffff';margin-left:200px>Id or password are incorrect</h3>";
    echo '<img src=""><h3 style="background-color: tomato;
color: #ffff";margin-left:200px;margin-top:-100px></h3>
<a href="login.html"><input type="button" name="login" value="Login Again" style="color:#ffffff;background-color:#80ff80;border:none;width:200px;height:50px;border-radius:5px;margin-left:41%;margin-top:300px;">';
   }
   
	?>
	
</form>
<script >
  if("Notification" in window)
  {
    let ask=Notification.requestPermission();
    ask.then(permission => {
      if(permission==="granted")
      {
        let msg=new Notification("Title",{
          body:"Hello User,See what's happening in the department-Team UNIFY"

        });
        msg.addEventListener("click",event=>
        {
          alert("click recieved");
        });
      }
    });
  }
  window.alert("loginsuccesful");
</script>
	</body>   
</html>