
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="studentstyle.css">
<link rel="icon" href="lo.png">
</head>
<body>
	<form method="post" action="mainpage.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$a=$_POST["id"];
session_start();
$_SESSION["uid"] = $a;
$b=$_POST["p"];
$m="select password from registera where id='$a'";
$r1=mysqli_query($conn,$m);
while($row = mysqli_fetch_assoc($r1)) {
      // $c = $row["userid"];
       $d=$row["password"];
   }
   if($b==$d)
   {
  echo '<span style="color:#FF0000;text-align:center;">login succesfully!</span>';
  echo '<div class="input-group">
      <button type="submit" class="btn" name="reg_user">continue</button>
    </div>';
   }
   else
   {
   	echo '<span style="color:#FF0000;text-align:center;">userid or password are incorrect!</span>';
    echo '<h1 style="background-color: #4d79ff;
color: #ffff";>registered succesfully</h1>
<a href="login.html"><input type="button" name="login" value="Login Again" style="color:blue">';
   }
   
	?>
	
</form>
	</body>   
</html>