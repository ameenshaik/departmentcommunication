
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" href="messages1.css">
<link rel="icon" href="lo.png">
</head>
<body>
	<form method="post" action="mainpage.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
session_start();
$a=$_SESSION["uid"];
$b=$_POST["messageto"];
$c=$_POST["content"];
$m = "insert into messages(fromid,toid,content) values($a,$b,'$c')";
$r1 = mysqli_query($conn,$m);
echo "<div class='fix'>";
	echo "<h1 class='h1'>";
echo "<img src=logo.png>";
echo "<input class='b2' type='button' value='LOGOUT' name='LOGOUT' >";
	echo "<input class= 'b2' type='button' value='EVENTS' name='Events'>";
	echo "<input class='b2'type='button' value='CALENDAR' name='Calendar'>";
	echo "<input class='b2'type='button' value='MESSAGES' name='Messages' >";
	echo "<input class='b2'type='button' value='PROFILE' name='Profile'>";
	echo "<input class='b2'type='button' value='POST' name='Post' >";
	echo "</div>";
	echo "</h1>";
	echo"<h2 style='margin-left:500px;margin-top:300px;font-family:monospace'>Message Delivered</h2>";
	echo"<h3 style='margin-left:0px;margin-top:-1500px;height:1500px;width:100px;background-color:#006699'></h3>";
echo "<table border='0'>

<tr>
<h1>CHAT HISTORY</h1>
<th>WITH</th>

<th>Message</th>

</tr>";

$r = "select toid,content from messages where fromid='$a'";
 $r1=mysqli_query($conn,$r);
while($row = mysqli_fetch_assoc($r1))

  {

  echo "<tr>";

  echo "<td>" .$row['toid'] . "</td>";

  echo "<td>" .$row['content'] . "</td>";

  echo "</tr>";

  }

echo "</table>";
?>
</form>
</body>
</html>