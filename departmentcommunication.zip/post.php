<html>
<head>
	<link rel="stylesheet" href="post.css">
	<div class="header" >
	</div> 
</head>
<body ">
<div class="fix">
	<h1 class="h1"  ">
	<img src=logo.png>
	<a href="homepage.html"><input class="b2" type="button" value="LOGOUT" name="LOGOUT " ></a>
	<a href="events.html"><input class= "b2"type="button" value="EVENTS" name="Events" ></a>
	<a href="calendar.html"><input class="b2"type="button" value="CALENDAR" name="Calendar" ></a>
	<a href="messages1.html"><input class="b2"type="button" value="MESSAGES" name="Messages" ></a>
	<a href="profile.php"><input class="b2"type="button" value="PROFILE" name="Profile"></a>
	<a href="cpost.php"><input class="b2"type="button" value="Feed" name="post" ></a>
	
	</div>
	
</h1>
<img src="po2.jpg" width="40%" style="margin-left: 130px;margin-top: 0px">
<form method = "post" action="cpost.php" enctype="multipart/form-data" style="margin-left: 400px;margin-top: -350px;width: 700px;height:600px;background-color:hsla(214, 100%, 64%, 0.60) ;float: right;">
	<textarea name="text" placeholder="say something about this post" ></textarea>
	<br>
	<label style="font-family: monospace;">or</label>
	<br>
	<br>
	<label style="margin-top: 100px;margin-left: 100px;color: #000000;font-family: monospace;">Post a picture:</label>
	<input style="margin-top: -20px;margin-left: 300px;border: none;" type="file" name="image">
	 <br>
	 <br>
	 <label style="margin-left: 100px;font-family: monospace;">Private</label>
	 <input type="radio" id="one" name="first_item" value="1" style="border: 0px;
    width: 100%;
    height: 1em;margin-right: -300px;margin-top: 30px" />

           <label style="margin-left: 400px;margin-top: 0px;font-family: monospace;">Public</label> <input type="radio" id="two" name="first_item" value="2" style="border: 0px;
    width: 100%;
    height: 1em;margin-left:-70px;margin-top: -80px"  />         <!--<input class="submit_form" name="submit" type="submit" value="Choose" tabindex="2" style="margin-right: : 300px" />-->
    <br>

	<input type="submit" name ="upload" value="UPLOAD" style="background-color: #ffff;color: #006699;margin-top: 10px;border:none;border-radius: 4px;width: 100px;	height: 50px;position: relative;margin-left: 180px;font-family: monospace;">
	<br>
            </form>

<h2 class="h2" style="margin-top: -1500px;height: 1800px"></h2>
	<img src="pi.jpg" width="40%" style="margin-left: 130px;margin-top: -300px">
	

</body>


</html>