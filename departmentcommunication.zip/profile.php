
<html>
<head>
	<link rel="stylesheet" href="post.css">
	<div class="header" >
	</div> 
</head>
<body>

     
	<a href="post.php"><input class="b2" type="button" value="CREATE" name="post " ></a>
     
	<a href="homepage.html"><input class="b2" type="button" value="LOGOUT" name="LOGOUT " ></a>
	<a href="events.html"><input class= "b2"type="button" value="EVENTS" name="Events" ></a>
	<a href="calendar.html"><input class="b2"type="button" value="CALENDAR" name="Calendar" ></a>
	<a href="messages1.html"><input class="b2"type="button" value="MESSAGES" name="Messages" ></a>
	<a href="cpost.php"><input class="b2"type="button" value="Feed" name="feed" ></a>

	<?php
	$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
session_start();
$a=$_SESSION['uid'];

echo "<div class='fix'>";
	echo "<h1 class='h1'>";
echo "<img src=logo.png>";
#echo "<input class='b2' type='button' value='LOGOUT' name='LOGOUT' ></a>";
	#echo "<input class= 'b2' type='button' value='EVENTS' name='Events'>";
	#echo "<input class='b2'type='button' value='CALENDAR' name='Calendar'>";
	#echo "<input class='b2'type='button' value='MESSAGES' name='Messages' >";
	#echo "<input class='b2'type='button' value='PROFILE' name='Profile'>";
	#echo "<input class='b2'type='button' value='POST' name='Post' >";
	#echo "</div>";
	#echo "</h1>";
echo "<img src='pro1.jpg' width='30%' style='margin-left: 130px;margin-top: 0px;float: right'>";
echo "<br>";
echo "<h1 style='color: #1a1a1a;font-family: monospace;margin-left: 250px'>";
echo "Profile";
echo "</h1>";
echo "<div class='labels' style='margin-top: 0px;margin-left: 250px;margin-bottom: 40px;color: #1a1a1a;font-family: monospace;height: 300px;width:200px;align-items: center;padding-left: : 30px;'>";


echo "<table border='0'>

<tr>

<th>Name</th>

<th>ID</th>

<th>Year</th>

<th>section</th>

</tr>";

 $r = "select * from register where id='$a'";
 $r1=mysqli_query($conn,$r);
while($row = mysqli_fetch_assoc($r1))

  {

  echo "<tr>";

  echo "<td>" .$row['name'] . "</td>";

  echo "<td>" .$row['id'] . "</td>";

  echo "<td>" .$row['year'] . "</td>";

  echo "<td>" . $row['section'] . "</td>";

  echo "</tr>";

  }

echo "</table>";


 echo "<br>";
 echo "<br>";
 echo "<br>";
echo "<a href='upassword.html'><input type='button' name='up' value='Change Password'></a>";

echo"<h3 style='margin-left:0px;margin-top:-1500px;height:500px;width:100px;background-color:#006699'></h2>";

?>
	
</body>


</html>