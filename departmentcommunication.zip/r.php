<html>
<head>
</head>
<body>
	<form method="post" action="login.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$a = $_POST["name"];
$b = $_POST["id"];
$c = $_POST["password"];
$d = $_POST["rpassword"];
$e = $_POST["year"];
$f = $_POST["section"];
$m = "insert into register(name,id,password,cpassword,year,section) values('$a','$b','$c','$d','$e','$f')";
$r1 = mysqli_query($conn,$m);

?>
	

	</form>
</body>
</html>