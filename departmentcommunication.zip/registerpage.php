<html>
<head>
	<link rel="stylesheet" href=".css">
<link rel="icon" href="lo.png">
</head>
<body style="background-image: url(e.png);">
	<div class="bg-modal">
	<div class="modal-content">
	<form method="post" action="login.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$a = $_POST["name"];
$b = $_POST["id"];
$c = $_POST["password"];
$d = $_POST["rpassword"];
$e = $_POST["year"];
$f = $_POST["section"];
$m = "insert into register(name,id,password,cpassword,year,section) values('$a','$b','$c','$d','$e','$f')";
$r1 = mysqli_query($conn,$m);

?>
<h3 style="font-family: monospace;
color: #ffffff;size:5px;margin-left: 500px">Registered succesfully</h3>
<a href="login.html"><input type="button" name="login" value="login" style="color:blue;border-radius: 5px;border:none;width: 100px;height: 50px;background-color:#1a1a1a;color: #ffffff;margin-left:30px;font-weight: bold;">
	</form>
</body>
</html>