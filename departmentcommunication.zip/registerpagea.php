<html>
<head>
	<link rel="stylesheet" href="studentstyle.css">
<link rel="icon" href="lo.png">
</head>
<body>
	<div class="bg-modal">
	<div class="modal-content">

		<img src="av.jpg" width="15%">
	<form method="post" action="login.html">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$a = $_POST["name"];
$b = $_POST["id"];
$c = $_POST["password"];
$d = $_POST["rpassword"];
$m = "insert into registera(name,id,password,cpassword) values('$a','$b','$c','$d')";
$r1 = mysqli_query($conn,$m);

?>
<h1 style="background-color: #4d79ff;
color: #ffff";>registered succesfully</h1>
<a href="login.html"><input type="button" name="login" value="login" style="color:blue">
	

	</form>
</body>
</html>