    <?php
        $db = mysqli_connect("localhost","root","","unify");
        $sql = "SELECT id,description,image FROM post";
        $result = mysqli_query($db,$sql);
        while($row = mysqli_fetch_array($result)){
            echo "<div id='img_div'>";
            echo '<img src="data:image/jpeg;base64,'.base64_encode($row['image']).'"width="30%" height="30%" style="margin-left:500px;" >';
            echo "<p id= 'description' style='margin-left:500px;'>".$row['description']."</p>";
        }
        ?>