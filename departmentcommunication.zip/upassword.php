
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "unify";
$conn = mysqli_connect($servername, $username, $password,$dbname);
$c=$_POST['cp'];
$a=$_POST['np'];
session_start();
$b=$_SESSION['uid'];
$d="update register set password='$a',cpassword='$a' where cpassword='$c'";
$r=mysqli_query($conn,$d);
header("location:mainpage.html");
?>